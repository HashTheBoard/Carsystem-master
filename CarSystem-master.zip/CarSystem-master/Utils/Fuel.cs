﻿using System;
using System.Linq;
using BrokeProtocol.Entities;
using BrokeProtocol.API;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using BrokeProtocol.Utility;

namespace CarSystem.Fuel
{

    public class Fuel: PlayerEvents
    {
        Main main;
        List<string> refilling = new List<string>();

        public Fuel() => main = Main.Instance;

        [Execution(ExecutionMode.Event)]
        public override bool Mount(ShPlayer player, ShMountable mount, byte seat) {
            if (!player.isHuman) return false;
            if (mount.isHuman || main.config.blacklistedcars.Contains(mount.name)) return false;
            int maxlvl;
            if(main.config.fueltank != null && main.config.fueltank.ContainsKey(mount.name))main.config.fueltank.TryGetValue(mount.name, out maxlvl);
            else maxlvl = 100;
            
            player.StartCoroutine(FuelCoroutine(player, mount, maxlvl));
            return true;
        }

        private IEnumerator FuelCoroutine(ShPlayer player, ShMountable mount, int maxlvl) {
            while (player.IsDriving) {
                if (mount is ShTransport transport) {
                    if (!transport.svEntity.CustomData.TryFetchCustomData<float>("fuelevel", out float fuel, null)) { 
                        transport.svEntity.CustomData.AddOrUpdate("fuelevel", maxlvl);
                        player.svPlayer.SendTextPanel($"&3Welcome to your car sir \n\n your driving a {mount.name}", "uue");
                        yield return new WaitForSeconds(3f);
                        DisplayUi(transport, player, fuel, maxlvl);
                    }
                    else {
                        if (transport.Velocity.magnitude > 2)
                        {
                            if (fuel <= 0)
                            {
                                player.svPlayer.StartCoroutine(StopCar(player, transport));
                                if (fuel >= -5 && fuel <= 0) player.svPlayer.SendGameMessage(main.config.EmptyFuel);
                            }else if (transport.Velocity.magnitude >= 5)
                            {
                                transport.svEntity.CustomData.AddOrUpdate<float>("fuelevel", fuel - 0.01f);
                            }
                            else
                            {
                                transport.svEntity.CustomData.AddOrUpdate<float>("fuelevel", fuel - 0.03f);
                            }
                        }
                            DisplayUi(transport, player, fuel, maxlvl);
                    }
                    yield return new WaitForSeconds(0.78f);
                }
            }
            player.svPlayer.DestroyTextPanel("mmc");
            yield break;  
        }

        private IEnumerator StopCar(ShPlayer player, ShTransport transport)
        {
            while (player.IsDriving)
            {
                transport.svMountable.SvRelocate(transport.svMountable.transform, null);
                yield return new WaitForSeconds(0.3f);
            }
        }
        
        [CustomTarget]
        public void StationEnter(ShEntity trigger, ShPhysical physical) {
            if (physical is ShPlayer p) {
                if (p.curMount is ShTransport trans) {
                    if (!p.isHuman) return;
                    if (trans.svEntity.CustomData.TryFetchCustomData<float>("fuelevel", out float fuel, null)) {
                        refilling.Add(p.username);
                        if (p.curMount.isHuman || main.config.blacklistedcars.Contains(p.curMount.name)) return;
                        int maxlvl;
                        if (main.config.fueltank != null && main.config.fueltank.ContainsKey(p.curMount.name)) main.config.fueltank.TryGetValue(p.curMount.name, out maxlvl);
                        else maxlvl = 100;

                        p.svPlayer.StartCoroutine(FuelRefilCoroutine(trans, p, maxlvl));
                    }
                }
            }
        }

        [CustomTarget]
        public void StationExit(ShEntity trigger, ShPhysical physical) {
            if (physical is ShPlayer p) {
                if (!p.isHuman) return;
                if (refilling.Contains(p.username)) refilling.Remove(p.username);
            }
        }

        private IEnumerator FuelRefilCoroutine(ShTransport trans, ShPlayer p, int maxlvl) {
            while (refilling.Contains(p.username) && p.IsDriving) {
                float fuel;
                if (!trans.svEntity.CustomData.TryFetchCustomData<float>("fuelevel", out fuel, null))
                if (fuel == null) fuel = 0.0f;
                if (fuel >= maxlvl) { p.svPlayer.SendGameMessage("&4Résérvoir Plein !"); yield return new WaitForSeconds(2.5f); }

                if (p.MyMoneyCount > 10)
                {
                    p.TransferMoney(DeltaInv.RemoveFromMe, 10);
                    trans.svEntity.CustomData.AddOrUpdate("fuelevel", fuel + 1.0f);
                    p.svPlayer.SendGameMessage("+1 litre Fuel");
                    yield return new WaitForSeconds(0.5f);
                }
                else { p.svPlayer.SendGameMessage("&4Fond insuffisent !"); yield return new WaitForSeconds(2.5f); }
            }

            yield break;
        }


        void DisplayUi(ShTransport transport, ShPlayer player, float fuel, int maxlvl) {
            float ScaleSpeed = transport.Velocity.magnitude;
            string speed = String.Format("{00}", Math.Round(ScaleSpeed * 1.5f, 0f));
            string sfuel = String.Format("{00}", Math.Round(fuel, 0f));
            if (ScaleSpeed < 70) player.svPlayer.SendTextPanel($"&3{transport.name} \n\n &2{speed} Km/h \n\n &8Essence: {sfuel}/{maxlvl}", "mmc");
            else if (ScaleSpeed < 110) player.svPlayer.SendTextPanel($"&3{transport.name} \n\n &e{speed} Km/h \n\n &8Essence: {sfuel}/{maxlvl}", "mmc");
            else player.svPlayer.SendTextPanel($"&3{transport.name} \n\n &c{speed} Km/h \n\n &8Essence: {sfuel}/{maxlvl}", "mmc");
        }
    }
}
